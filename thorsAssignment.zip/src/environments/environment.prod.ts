export const environment = {
  production: true,
  apiURL: 'https://magni-careers.azurewebsites.net/api/'
};
