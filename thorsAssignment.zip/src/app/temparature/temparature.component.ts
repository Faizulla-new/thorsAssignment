import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-temparature',
  templateUrl: './temparature.component.html',
  styleUrls: ['./temparature.component.css']
})
export class TemparatureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
